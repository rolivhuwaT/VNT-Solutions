# VNT Solutions — Static HTML, CSS and JavaScript

A seven-page responsive website. No build tools, npm, TypeScript, framework or server required.

## Open locally
1. Extract the ZIP.
2. Double-click **index.html** to open the homepage in a browser.
3. Or open the folder with VS Code and optionally use Live Server.

## Structure
- index.html, about.html, services.html, projects.html, hardware.html, quote.html, contact.html
- assets/css/styles.css — all styles
- assets/js/main.js — navigation, slideshows, catalogue navigation and quote form logic
- assets/images/vnt-logo.png — supplied VNT logo / favicon

## Editing
- Change page content and product/material entries in **assets/js/main.js** (sections are created by JavaScript and inserted into the HTML page).
- Change colours, Montserrat typography, spacing and rounded styles in **assets/css/styles.css**.
- External hero photography currently loads from Unsplash URLs and Montserrat loads from Google Fonts. Internet access is needed for these external resources.
- Amasis MT Pro Black requires a licensed font file to be embedded for consistent display; the wordmark has a fallback.

## Quotation form
The form validates required fields and opens the visitor's email application with a prepared message to info@vntsolutions.co.za. It does **not** send emails automatically, store enquiries or connect to a backend.

## Promotions
The Black Friday catalogue is a sample layout, not verified live pricing or current VNT offers. Replace with approved offers before public use. No cart or online checkout.
