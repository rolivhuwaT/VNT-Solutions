const page = (document.body.dataset.page || 'index');
const asset = (name) => `assets/images/${name}`;
const heroImages = {
    construction: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=2000&q=85',
    architecture: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=2000&q=85',
    engineering: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=2000&q=85',
    house: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=2000&q=85',
    renovation: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=2000&q=85',
    materials: 'https://images.unsplash.com/photo-1531835551805-16d864c8d311?auto=format&fit=crop&w=2000&q=85',
    factory: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=2000&q=85',
};
const pageSlides = {
    index: [
        { kicker: 'Building with purpose', title: 'Constructing a better tomorrow.', body: 'Trusted building and infrastructure solutions from concept to completion.', photo: heroImages.construction, cta: 'Explore our services', href: 'services.html' },
        { kicker: 'Residential development', title: 'Spaces designed for life.', body: 'Practical, beautiful developments made for the people who use them.', photo: heroImages.house, cta: 'Request a quote', href: 'quote.html' },
        { kicker: 'VNT Hardware', title: 'Materials for every build.', body: 'Find quality construction essentials and request a tailored supply quotation.', photo: heroImages.materials, cta: 'Explore hardware', href: 'hardware.html' }
    ],
    about: [
        { kicker: 'Our company', title: 'Built on trust. Driven by quality.', body: 'Discover the commitment behind VNT Solutions.', photo: heroImages.architecture },
        { kicker: 'How we work', title: 'From vision to delivery.', body: 'Focused planning, clear communication and careful execution.', photo: heroImages.construction },
        { kicker: 'Our priorities', title: 'People. Projects. Progress.', body: 'Our work centres on long-term value for clients and communities.', photo: heroImages.house }
    ],
    services: [
        { kicker: 'What we do', title: 'End-to-end building solutions.', body: 'Commercial, residential, industrial and renovation services.', photo: heroImages.construction },
        { kicker: 'Commercial infrastructure', title: 'Built for the way you work.', body: 'Functional spaces supporting organisations and communities.', photo: heroImages.factory },
        { kicker: 'Maintenance & renovations', title: 'Renew what matters.', body: 'Improve and extend the life of existing properties.', photo: heroImages.renovation }
    ],
    projects: [
        { kicker: 'Our work', title: 'Projects worth building.', body: 'Explore the range of work and solutions VNT can support.', photo: heroImages.architecture },
        { kicker: 'Built environments', title: 'Spaces that make an impact.', body: 'A flexible approach across commercial and residential projects.', photo: heroImages.house },
        { kicker: 'Your next project', title: 'Let’s build it together.', body: 'Tell us what you have in mind.', photo: heroImages.construction, cta: 'Request a quote', href: 'quote.html' }
    ],
    hardware: [
        { kicker: 'VNT Hardware', title: 'Your building materials partner.', body: 'From foundation materials to roofing and finishes. Enquire for pricing and availability.', photo: heroImages.materials, cta: 'Request materials quote', href: 'quote.html' },
        { kicker: 'Building essentials', title: 'Everything starts with the right supplies.', body: 'Browse materials by category and send us your requirements.', photo: heroImages.construction, cta: 'Browse materials', href: '#materials' },
        { kicker: 'Promotions', title: 'Discover our Black Friday catalogue.', body: 'Browse the promotional layout and enquire about current offers.', photo: heroImages.factory, cta: 'View catalogue', href: '#black-friday' }
    ],
    quote: [
        { kicker: 'Get started', title: 'Tell us what you need.', body: 'Request a quote for construction projects or hardware supplies.', photo: heroImages.architecture },
        { kicker: 'Hardware enquiries', title: 'A tailored materials quotation.', body: 'Share the type, quantity and delivery details.', photo: heroImages.materials },
        { kicker: 'Construction enquiries', title: 'Your project begins here.', body: 'We would love to hear about your building plans.', photo: heroImages.house }
    ],
    contact: [
        { kicker: 'Contact us', title: 'Let’s start a conversation.', body: 'Our team is here to answer your questions about products and services.', photo: heroImages.architecture },
        { kicker: 'Visit us', title: 'Find us in Braamfontein.', body: '20 De Korte Street, Samro Office Park, Johannesburg.', photo: heroImages.factory },
        { kicker: 'Get in touch', title: 'We’re ready to assist.', body: 'Call, email or send your enquiry.', photo: heroImages.construction }
    ],
};
const nav = [['Home', 'index.html'], ['About', 'about.html'], ['Services', 'services.html'], ['Projects', 'projects.html'], ['Hardware', 'hardware.html'], ['Contact', 'contact.html']];
const socials = [
    ['TikTok', 'https://www.tiktok.com/@vntsolutions', '♪'], ['Instagram', 'https://www.instagram.com/vnt_solutions/', '◎'],
    ['Facebook', 'https://www.facebook.com/@vntsolutions', 'f'], ['X', 'https://x.com/vntsolutions', '𝕏']
];
function socialIcons() { return `<div class="socials">${socials.map(([name, url, symbol]) => `<a aria-label="VNT on ${name}" href="${url}" target="_blank" rel="noopener noreferrer" title="${name}">${symbol}</a>`).join('')}</div>`; }
function header() { return `<header class="site-header"><div class="container topbar"><a class="brand" href="index.html" aria-label="VNT Solutions home"><span class="brand-plate"><img src="${asset('vnt-logo.png')}" alt="VNT logo"/></span><span class="brand-word"><strong>VNT</strong><small>SOLUTIONS</small></span></a><button class="menu-toggle" aria-label="Open navigation" aria-controls="site-nav" aria-expanded="false"><span></span><span></span><span></span></button><nav id="site-nav" class="nav">${nav.map(([label, link]) => `<a href="${link}" class="${page === 'index' && link === 'index.html' || link === page + '.html' ? 'active' : ''}">${label}</a>`).join('')}<a class="btn btn-primary nav-quote" href="quote.html">Request a Quote</a></nav></div></header>`; }
function hero() { return `<section class="hero" aria-label="Featured ${page} slides"><div class="hero-slides">${pageSlides[page].map((s, i) => `<div class="hero-slide ${i === 0 ? 'is-active' : ''}" style="background-image:linear-gradient(95deg,rgba(2,18,42,.88),rgba(3,21,45,.36)),url('${s.photo}')" aria-hidden="${i !== 0}"><div class="container slide-content"><span class="eyebrow">${s.kicker}</span><h1>${s.title}</h1><p>${s.body}</p>${s.cta ? `<a class="btn btn-primary" href="${s.href}">${s.cta}</a>` : ''}</div></div>`).join('')}</div><div class="hero-controls container"><button class="slide-prev" aria-label="Previous slide">‹</button><span class="slide-count" aria-live="polite">01 / 03</span><button class="slide-next" aria-label="Next slide">›</button><div class="slide-dots">${pageSlides[page].map((_, i) => `<button aria-label="Go to slide ${i + 1}" class="${i === 0 ? 'active' : ''}" data-slide="${i}"></button>`).join('')}</div></div></section>`; }
function footer() { return `<footer class="footer"><div class="container footer-grid"><div><a class="brand footer-brand" href="index.html"><span class="brand-plate"><img src="${asset('vnt-logo.png')}" alt="VNT"/></span><span class="brand-word"><strong>VNT</strong><small>SOLUTIONS</small></span></a><p>Construction, infrastructure development, renovations and building materials.</p>${socialIcons()}</div><div><h3>Explore</h3>${nav.map(([n, l]) => `<a href="${l}">${n}</a>`).join('')}</div><div><h3>Get in touch</h3><a href="tel:+27110274379">011 027 4379</a><a href="tel:+27795249433">079 524 9433</a><a href="mailto:info@vntsolutions.co.za">info@vntsolutions.co.za</a><p>20 De Korte Street, Samro Office Park, 7th Floor, Braamfontein, Johannesburg, 2001</p></div></div><div class="container footer-bottom"><span>© ${new Date().getFullYear()} VNT Solutions. All rights reserved.</span><span>Monday – Friday · 08:30 – 17:30</span></div></footer>`; }
const services = [
    { title: 'Commercial Infrastructure', img: heroImages.factory, detail: 'Purpose-built commercial spaces and essential infrastructure to support business growth.' },
    { title: 'Residential Development', img: heroImages.house, detail: 'Residential construction designed with functionality, comfort and long-term value in mind.' },
    { title: 'Industrial Construction', img: heroImages.construction, detail: 'Durable, practical building solutions for industrial and operational environments.' },
    { title: 'Maintenance & Renovations', img: heroImages.renovation, detail: 'Repairs, upgrades and property improvements to keep your spaces performing.' },
];
function serviceCards() { return `<div class="card-grid">${services.map((s, i) => `<article class="service-card"><img loading="lazy" src="${s.img}" alt="${s.title}"/><div class="service-info"><span class="item-number">0${i + 1}</span><h3>${s.title}</h3><p>${s.detail}</p><a class="text-link" href="quote.html?service=${encodeURIComponent(s.title)}">Request a Quote</a></div></article>`).join('')}</div>`; }
function sectionHeading(kicker, title, desc = '') { return `<div class="section-heading"><span class="eyebrow blue">${kicker}</span><h2>${title}</h2>${desc ? `<p>${desc}</p>` : ''}</div>`; }
function home() { return `<section class="section container">${sectionHeading('What we do', 'Building South Africa, together.', 'From new developments to renovations, VNT Solutions is ready to help you realise the next step.')}${serviceCards()}</section><section class="band"><div class="container split"><div>${sectionHeading('About VNT', 'Solutions you can build on.', 'We bring a thoughtful, project-focused approach to construction and building material supply.')}<a class="btn btn-light" href="about.html">Discover our company</a></div><img loading="lazy" src="${heroImages.architecture}" alt="Contemporary building architecture"/></div></section><section class="section container">${sectionHeading('VNT Hardware', 'Materials for your next project.', 'Browse popular building material categories and request a tailored quotation.')}<div class="feature-grid">${['Cement & concrete', 'Sand & aggregates', 'Roofing materials'].map((x, i) => `<a class="feature-tile" href="hardware.html"><span class="feature-icon">${['▥', '◈', '⌂'][i]}</span><h3>${x}</h3><span>Explore supplies</span></a>`).join('')}</div></section><section class="cta-panel container"><h2>Have a project in mind?</h2><p>Share your requirements and our team can discuss the next steps with you.</p><a href="quote.html" class="btn btn-primary">Request a Quote</a></section>`; }
function about() { return `<section class="section container split about-split"><div>${sectionHeading('Who we are', 'A practical partner for your projects.')}<p>VNT Solutions supports residential, commercial and industrial development, maintenance and renovation needs, alongside building-material supply enquiries.</p><p>We believe good project delivery begins with understanding our clients, setting realistic expectations and paying close attention to the details that matter.</p><a href="contact.html" class="btn btn-primary">Talk to us</a></div><img loading="lazy" src="${heroImages.construction}" alt="Construction site"/></section><section class="section muted"><div class="container">${sectionHeading('Our approach', 'Our guiding principles')}<div class="feature-grid">${[['01', 'Quality', 'Careful workmanship and reliable project execution.'], ['02', 'Communication', 'Clear conversations at every stage of the work.'], ['03', 'Value', 'Solutions suited to project objectives and budgets.']].map(([n, t, d]) => `<article class="feature-tile"><span class="item-number">${n}</span><h3>${t}</h3><p>${d}</p></article>`).join('')}</div></div></section>`; }
function servicesPage() { return `<section class="section container">${sectionHeading('Our services', 'Construction expertise across sectors.', 'Whether you are planning a new build, improving an existing property or sourcing materials, we would like to hear from you.')}${serviceCards()}</section><section class="cta-panel container"><h2>Let’s discuss your requirements.</h2><p>Receive a quotation based on the work you need.</p><a class="btn btn-primary" href="quote.html">Request a Quote</a></section>`; }
function projects() { return `<section class="section container">${sectionHeading('Project gallery', 'Spaces and possibilities.', 'The photographs below are illustrative examples of project types, not verified VNT project completions. Replace them with approved VNT portfolio images before public launch.')}<div class="project-grid">${[{ n: 'Residential development', i: heroImages.house }, { n: 'Commercial infrastructure', i: heroImages.factory }, { n: 'Construction works', i: heroImages.construction }, { n: 'Maintenance & renovation', i: heroImages.renovation }].map(x => `<article class="project-tile"><img loading="lazy" src="${x.i}" alt="Illustrative ${x.n}"/><div><h3>${x.n}</h3><p>Illustrative project category</p></div></article>`).join('')}</div></section><section class="cta-panel container"><h2>Work with VNT Solutions.</h2><p>Send us your next construction project brief.</p><a href="quote.html" class="btn btn-primary">Start an enquiry</a></section>`; }
const materials = [
    { name: '42.5N Cement', category: 'Cement', details: '50 kg bags and bulk supply enquiries', symbol: '▥' },
    { name: '32.5N Cement', category: 'Cement', details: 'General purpose cement supply', symbol: '▥' },
    { name: 'Building Sand', category: 'Sand & Aggregates', details: 'Bulk and load-based enquiries', symbol: '◈' },
    { name: 'River Sand', category: 'Sand & Aggregates', details: 'Sand for mixing and building work', symbol: '◈' },
    { name: 'Plaster Sand', category: 'Sand & Aggregates', details: 'Fine sand for plaster applications', symbol: '◈' },
    { name: 'Concrete Blocks & Bricks', category: 'Bricks & Blocks', details: 'Various sizes and types', symbol: '▦' },
    { name: 'Paving Bricks', category: 'Bricks & Blocks', details: 'Paving materials and finishes', symbol: '▦' },
    { name: 'Reinforcing Steel', category: 'Steel & Fencing', details: 'Steel reinforcement enquiries', symbol: '╱' },
    { name: 'Mesh & Fencing', category: 'Steel & Fencing', details: 'Mesh and fencing products', symbol: '▤' },
    { name: 'Roof Sheets', category: 'Roofing', details: 'Galvanised and other roofing profiles', symbol: '⌂' },
    { name: 'Concrete Roof Tiles', category: 'Roofing', details: 'Profiles and colour options', symbol: '⌂' },
    { name: 'PVC Pipes', category: 'Plumbing', details: 'Pipe sizes and fittings', symbol: '◯' },
    { name: 'Door Frames & Locks', category: 'Finishes', details: 'Doors, frames and hardware', symbol: '▯' },
];
const categories = ['All', 'Cement', 'Sand & Aggregates', 'Bricks & Blocks', 'Roofing', 'Steel & Fencing', 'Plumbing', 'Finishes'];
const escapeHTML = (s) => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));
function materialCard(m) { return `<article class="material-card" data-category="${escapeHTML(m.category)}"><div class="material-visual" aria-hidden="true"><span>${m.symbol}</span></div><div class="material-copy"><small>${m.category}</small><h3>${m.name}</h3><p>${m.details}</p><a class="btn btn-outline btn-small" href="quote.html?material=${encodeURIComponent(m.name)}">Request Quote</a></div></article>`; }
function hardware() { return `<section class="section container" id="black-friday">${sectionHeading('VNT Hardware', 'Black Friday catalogue', 'Explore our building-material promotional catalogue concept. Current prices, discounts, product availability and sale dates must be confirmed by VNT before any offer is published.')}<div class="promo-cover"><div><span class="promo-overline">VNT HARDWARE</span><h2>BLACK<br/><em>FRIDAY</em></h2><p>Build bigger. Plan smarter. Ask about our current specials.</p><a class="btn btn-light" href="quote.html?service=Black%20Friday%20materials">Enquire about offers</a></div><div class="promo-stamp">SPECIAL<br/>ENQUIRIES<br/>WELCOME</div></div><div class="catalogue"><div class="catalogue-top"><div><span class="eyebrow blue">Interactive catalogue</span><h3>Browse materials</h3></div><div class="catalogue-pager"><button id="catalogue-prev" aria-label="Previous catalogue page">‹</button><span id="catalogue-count">1 / 3</span><button id="catalogue-next" aria-label="Next catalogue page">›</button></div></div><div id="catalogue-pages">${[0, 1, 2].map((n) => `<div class="catalogue-page ${n === 0 ? 'visible' : ''}" data-catalogue-page="${n}"><div class="catalogue-page-heading"><span>VNT HARDWARE</span><strong>${['Foundations & aggregates', 'Structure & roofing', 'Finishing essentials'][n]}</strong></div><div class="catalogue-items">${materials.slice(n * 4, n * 4 + 4).map(materialCard).join('')}</div><p class="catalogue-disclaimer">Enquire for current pricing and availability. No discounts or prices are guaranteed by this preview.</p></div>`).join('')}</div></div></section><section class="section muted" id="materials"><div class="container">${sectionHeading('Building materials', 'Explore our range', 'Use the category filters to find materials and request a quotation. No cart or online checkout.')}<div class="category-filter" aria-label="Filter materials">${categories.map((c, i) => `<button class="chip ${i === 0 ? 'selected' : ''}" data-filter="${escapeHTML(c)}">${c}</button>`).join('')}</div><div class="materials-grid" id="material-grid">${materials.map(materialCard).join('')}</div></div></section><section class="cta-panel container"><h2>Need multiple materials?</h2><p>Send us your full list, quantities and delivery information in one quotation request.</p><a href="quote.html" class="btn btn-primary">Request a Materials Quote</a></section>`; }
function quote() { return `<section class="section container"><div class="form-layout"><div>${sectionHeading('Request a quote', 'Tell us about your requirements.', 'Complete the form and generate an email enquiry to VNT Solutions.')}<div class="info-card"><h3>What to include</h3><p>For building materials: describe the items, sizes, quantities and delivery location.</p><p>For construction: share the type of work, proposed location and expected timeframe.</p><p><strong>Note:</strong> This static-site version opens your email application. It does not store submissions or transmit them to a server automatically.</p></div></div><form id="quote-form" class="form-card"><div class="form-grid"><label>Full name <span>*</span><input name="name" required maxlength="100" autocomplete="name"/></label><label>Email address <span>*</span><input type="email" name="email" required autocomplete="email"/></label><label>Contact number <span>*</span><input type="tel" name="phone" required autocomplete="tel"/></label><label>Enquiry type <span>*</span><select name="type" required><option value="">Select a type</option><option>Building Materials</option><option>Construction Project</option><option>Other</option></select></label><label class="full">Material / service requested <span>*</span><input name="item" required placeholder="e.g. 42.5N Cement or Residential Development"/></label><label>Quantity / scope<input name="quantity" placeholder="e.g. 50 bags, 120 m²"/></label><label>Required date<input type="date" name="date"/></label><label>Delivery / collection <span>*</span><select name="fulfilment" id="fulfilment" required><option value="">Select preference</option><option>Delivery</option><option>Collection</option><option>Not applicable</option></select></label><label>Project / delivery area <span>*</span><input name="area" required placeholder="Suburb, city or site area"/></label><label class="full" id="address-label">Delivery address<textarea name="address" rows="2" placeholder="Street, suburb, city, postal code"></textarea></label><label class="full">More information <span>*</span><textarea name="notes" required rows="5" placeholder="Tell us more about your requirements"></textarea></label><label class="full checkbox-label"><input type="checkbox" required name="consent"/> I agree to VNT Solutions using these details to respond to my quotation enquiry. <span>*</span></label></div><button type="submit" class="btn btn-primary submit">Prepare Email Quote Request</button><p class="form-note" id="quote-status" role="status">Fields marked * are required.</p></form></div></section>`; }
function contact() { const addr = '20 De Korte Street, Samro Office Park, 7th Floor, Braamfontein, Johannesburg, 2001, South Africa'; return `<section class="section container">${sectionHeading('Contact us', 'We would love to hear from you.', 'Our office hours are 8:30 AM to 5:30 PM, Monday to Friday. For information about our products and services, contact us by phone, email or post.')}<div class="contact-layout"><div class="contact-cards"><article class="info-card"><h3>Call us</h3><p><strong>Landline:</strong> <a href="tel:+27110274379">011-027-4379</a></p><p><strong>Cell:</strong> <a href="tel:+27795249433">079-524-9433</a></p></article><article class="info-card"><h3>Email</h3><p><a href="mailto:info@vntsolutions.co.za">info@vntsolutions.co.za</a></p></article><article class="info-card"><h3>Physical address</h3><p>20 De Korte Street<br/>Samro Office Park, 7th Floor<br/>Braamfontein, Johannesburg, 2001</p><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}" target="_blank" rel="noopener noreferrer" class="text-link">Open in Google Maps</a></article><article class="info-card"><h3>Follow VNT Solutions</h3>${socialIcons()}</article></div><div class="map-card"><iframe title="Map showing Samro Office Park in Braamfontein" src="https://www.google.com/maps?q=${encodeURIComponent(addr)}&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div></div></section><section class="cta-panel container"><h2>Ready to talk about a project?</h2><p>Send us your requirements and let’s discuss the details.</p><a href="quote.html" class="btn btn-primary">Request a Quote</a></section>`; }
const pageContents = { index: home, about, services: servicesPage, projects, hardware, quote, contact };
const app = document.querySelector('#app');
if (app) {
    app.innerHTML = header() + `<main>${hero()}${pageContents[page]()}</main>` + footer();
}
// Responsive menu
const toggle = document.querySelector('.menu-toggle');
toggle?.addEventListener('click', () => { const nav = document.querySelector('.nav'); const expanded = toggle.getAttribute('aria-expanded') === 'true'; toggle.setAttribute('aria-expanded', String(!expanded)); nav?.classList.toggle('open', !expanded); });
// Hero slider, buttons and keyboard support.
const slides = [...document.querySelectorAll('.hero-slide')];
const dots = [...document.querySelectorAll('.slide-dots button')];
let slide = 0;
const showSlide = (idx) => { slide = (idx + slides.length) % slides.length; slides.forEach((el, i) => { el.classList.toggle('is-active', slide === i); el.setAttribute('aria-hidden', String(slide !== i)); }); dots.forEach((d, i) => d.classList.toggle('active', slide === i)); const count = document.querySelector('.slide-count'); if (count)
    count.textContent = `${String(slide + 1).padStart(2, '0')} / ${String(slides.length).padStart(2, '0')}`; };
document.querySelector('.slide-next')?.addEventListener('click', () => showSlide(slide + 1));
document.querySelector('.slide-prev')?.addEventListener('click', () => showSlide(slide - 1));
dots.forEach((dot, i) => dot.addEventListener('click', () => showSlide(i)));
if (slides.length > 1 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.setInterval(() => { if (!document.hidden)
        showSlide(slide + 1); }, 6500);
}
// Hardware filters and catalogue controls.
document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => { const filter = button.dataset.filter; document.querySelectorAll('[data-filter]').forEach(b => b.classList.toggle('selected', b === button)); document.querySelectorAll('#material-grid .material-card').forEach(card => card.hidden = filter !== 'All' && card.dataset.category !== filter); }));
const spreads = [...document.querySelectorAll('[data-catalogue-page]')];
let spread = 0;
function showSpread(n) { spread = (n + spreads.length) % spreads.length; spreads.forEach((s, i) => s.classList.toggle('visible', i === spread)); const counter = document.querySelector('#catalogue-count'); if (counter)
    counter.textContent = `${spread + 1} / ${spreads.length}`; }
document.querySelector('#catalogue-prev')?.addEventListener('click', () => showSpread(spread - 1));
document.querySelector('#catalogue-next')?.addEventListener('click', () => showSpread(spread + 1));
// Populate quotation form from material/service links.
const params = new URLSearchParams(location.search);
const item = document.querySelector('input[name="item"]');
const type = document.querySelector('select[name="type"]');
if (item) {
    item.value = params.get('material') || params.get('service') || '';
    if (params.has('material') && type)
        type.value = 'Building Materials';
    if (params.has('service') && type)
        type.value = params.get('service')?.includes('materials') ? 'Building Materials' : 'Construction Project';
}
const fulfilment = document.querySelector('#fulfilment');
const address = document.querySelector('textarea[name="address"]');
const addressLabel = document.querySelector('#address-label');
fulfilment?.addEventListener('change', () => { const delivery = fulfilment.value === 'Delivery'; if (address)
    address.required = delivery; if (addressLabel)
    addressLabel.classList.toggle('delivery-required', delivery); });
const quoteForm = document.querySelector('#quote-form');
quoteForm?.addEventListener('submit', e => { e.preventDefault(); if (!quoteForm.reportValidity())
    return; const fd = new FormData(quoteForm); const get = (key) => String(fd.get(key) || ''); const message = ['VNT Solutions - Quotation Enquiry', '', `Name: ${get('name')}`, `Email: ${get('email')}`, `Phone: ${get('phone')}`, `Type: ${get('type')}`, `Material/service: ${get('item')}`, `Quantity/scope: ${get('quantity')}`, `Required date: ${get('date')}`, `Delivery/collection: ${get('fulfilment')}`, `Project/delivery area: ${get('area')}`, `Address: ${get('address')}`, '', `Additional information:\n${get('notes')}`].join('\n'); const subject = `VNT Quote Request - ${get('item').slice(0, 65)}`; const link = `mailto:info@vntsolutions.co.za?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`; const status = document.querySelector('#quote-status'); if (status)
    status.textContent = 'Your email application will open with your quotation details. Please send the email to complete your request.'; window.location.href = link; });
