# VNT Solutions — hosting-ready static website

## What this package is
Seven separate HTML pages with shared CSS and vanilla JavaScript. No Node.js, TypeScript, npm or database is required to publish the website.

**This is the available static HTML/CSS/JS implementation, not a verified export of the hosted Sites project repository.**

## Contents
- `index.html` — homepage (the default landing page)
- `about.html`, `services.html`, `projects.html`, `hardware.html`, `quote.html`, `contact.html`
- `assets/css/styles.css` — page styling
- `assets/js/main.js` — navigation, slideshows, catalogue, quote form
- `assets/images/vnt-logo.png` — VNT logo
- `favicon.ico` — browser tab icon
- `.htaccess` — optional Apache/cPanel defaults
- `web.config` — optional Microsoft IIS defaults
- `404.html` — error page

## Publish with cPanel / shared hosting (Apache)
1. Open the hosting account **File Manager**, then `public_html` (or your chosen domain's document root).
2. Back up old website files first.
3. Upload this ZIP and **extract its contents directly into `public_html`**. `index.html` and `assets` must be at the same directory level; do not leave an extra containing folder.
4. Check the site at `https://your-domain.example/index.html`, then test all menu links.
5. Enable HTTPS/SSL on your hosting provider. Point DNS to that hosting provider per its instructions.

## Publish with Netlify
Drag the extracted folder containing `index.html` into Netlify's manual deploy interface, or link it as a static site with no build command. The publish directory is `/`.

## Publish with GitHub Pages
Upload the files to the repository root and enable Pages deployment from the selected branch root. Because links and assets are relative, the pages work under a project subpath too.

## Publish on IIS
Place all files directly under the IIS site's physical path. `web.config` sets `index.html` as the default document. The `Static Content` IIS feature must be enabled.

## Local testing
Open `index.html` directly in your browser, or use VS Code Live Server. For a local test server you can run `python -m http.server 8000` in this folder and browse `http://localhost:8000`.

## Important before launch
- The quote form creates an email draft via `mailto:`. It **does not** send or save data on a server; users must send the email from their own email application.
- Hero and other stock images use remote Unsplash URLs and require internet. Replace them with approved project photos stored in `assets/images` and update their locations in `assets/js/main.js` before a fully self-contained launch.
- Montserrat loads from Google Fonts; Amasis MT Pro Black is not bundled. The brand wordmark uses a fallback where that font is unavailable.
- The Black Friday catalogue is a design preview only. Check pricing, offers, dates and image rights before publishing any advertisements. No online payments or shopping cart are included.
- Verify company descriptions, project imagery, social profiles, phone numbers, privacy notice and contact details before public launch.
